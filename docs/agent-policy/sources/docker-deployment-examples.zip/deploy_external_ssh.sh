#!/bin/sh

set -e

# A POSIX variable
OPTIND=1 # Reset in case getopts has been used previously in the shell.

# Initialize our own variables:
deploy_host=""
deploy_port="22"
deploy_user=""
docker_compose=""
die_now=0

die_later() {
    echo $1
    die_now=1
}

die_now() {
    [ $die_now -eq 0 ] || exit
}

while getopts "d:h:p:u:v" opt; do
  case "$opt" in
    d) docker_compose="$OPTARG"
      ;;
    h) deploy_host="$OPTARG"
      ;;
    p) deploy_port="$OPTARG"
      ;;
    u) deploy_user="$OPTARG"
      ;;
    v) set -x
      ;;
  esac
done

shift $((OPTIND-1))

[ "${1:-}" = "--" ] && shift

[ -z "$deploy_host" ] && die_later "Deploy host must be set! Use the '-h' option."
[ -z "$deploy_user" ] && die_later "Deploy user must be set! Use the '-u' option."
[ -z "$docker_compose" ] && die_later "Docker Compose command must be set! Use the '-d' option."
[ -z "${OPENAI_API_KEY:-}" ] && die_later "OPENAI_API_KEY must be set for deployment."
[ ! -f "nginx/nginx.conf" ] && die_later "nginx/nginx.conf must exist in the deployment workspace."

die_now

# Compose targets a remote Docker daemon, so bind-mounted files must exist on
# that host rather than only in the CI workspace.
remote_home="$(ssh -o StrictHostKeyChecking=no "$deploy_user@$deploy_host" -p "$deploy_port" 'printf %s "$HOME"')"
[ -z "$remote_home" ] && die_later "Could not determine the deployment user's remote home directory."
case "$remote_home" in
  /*) ;;
  *) die_later "The deployment user's remote home directory must be an absolute path." ;;
esac
die_now

remote_nginx_dir="$remote_home/.config/ai-for-parts/nginx"
remote_nginx_config="$remote_nginx_dir/nginx.conf"
ssh -o StrictHostKeyChecking=no "$deploy_user@$deploy_host" -p "$deploy_port" "mkdir -p '$remote_nginx_dir'"
scp -o StrictHostKeyChecking=no -P "$deploy_port" "nginx/nginx.conf" "$deploy_user@$deploy_host:$remote_nginx_config"
export NGINX_CONFIG_PATH="$remote_nginx_config"

# First save the images before changing the DOCKER_HOST
# Note: the images must already be present in docker (run build or pull first)
images=""
for img in $($docker_compose config | awk '{if ($1 == "image:") print $2;}'); do
  images="$images $img"
done

docker save -o saved_images.tar $images

export DOCKER_HOST="ssh://$deploy_user@$deploy_host:$deploy_port"
export DISPLAY=""

# docker-compose changed the way SSH connection works in 1.28.0. We often see connection issues on EYE+ demo setups
# that might be related to this. Setting COMPOSE_PARAMIKO_SSH=1 seems to improve the situation.
# Another fix could be to use "docker compose" instead of "docker-compose" (not tested)
#
# https://github.com/docker/compose/issues/8096
# https://github.com/docker/compose/issues/8221#issuecomment-802875958
export COMPOSE_PARAMIKO_SSH=1

echo "$DOCKER_HOST"
echo "Connecting to $deploy_host"
echo "Load images"
docker load -i saved_images.tar

echo "Stopping running containers"
# docker-compose down does not work properly anymore over SSH, see the following link:
# https://github.com/docker/compose/issues/8856#issuecomment-1244773422
until $docker_compose down --remove-orphans; do sleep 1; done

echo "Starting application..."
$docker_compose up -d --no-build search-engine oauth2-proxy nginx

echo "Removing dangling objects"
ssh -o StrictHostKeyChecking=no "$deploy_user@$deploy_host" -p $deploy_port "docker image prune -af"
